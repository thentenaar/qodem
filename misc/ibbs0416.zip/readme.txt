The Telnet/Dial-Up BBS Guide - Readme.txt
------------------------------------------
Welcome to the April 2016 edition of the Telnet BBS Guide &
US/Canada Dial-Up BBS guide.

We are still doing a bit of debugging and maintenance. Still a
work in progress.

A note to BBS Sysops - When you are "claiming" your BBS, you are
letting me know that you wish to be able to edit your own BBS
listing. Once I approve your account, you will then be able to
edit your listing any time you wish. Please do not use the reporting
feature to let me know what needs to be updated. You will be
able to do that once your account is approved and linked to
your listing.

Thanks, and continue to enjoy the ride!


- Dave

The Telnet BBS Guide
http://www.telnetbbsguide.com

The BBS Corner
http://www.bbscorner.com

Diamond Mine Online BBS
http://www.dmine.com (info) & http://www.dmine.net (BBS access)
telnet://bbs.dmine.net



