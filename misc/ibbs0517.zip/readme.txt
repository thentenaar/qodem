The Telnet/Dial-Up BBS Guide - Readme.txt
------------------------------------------
Welcome to the May 2017 edition of the Telnet BBS Guide &
US/Canada Dial-Up BBS guide.

We are aware that the search feature on the site may not work
properly. Don't worry, your BBS is still there! Just look in
the alphabetical listings and you'll find your BBS! Thanks!

We are on Facebook! Look us up at The BBS Corner and Telnet BBS Guide!

https://www.facebook.com/thebbscorner/

Notes for BBS Sysops:

We are aware that some of you are moving your BBSes to a non-
standard port from the default telnet port number (23). If you
do move to a non-standard port, please either update your listing
or let us know and we'll update your listing for you. Remember,
we do verify your BBS listing once a month. If it is not in
operation, we will mark it down. We will wait another month.
If it's still down, we will delete it from the database. So,
please keep your listing updated if you do indeed make
any address changes. Thanks!

And of course, if your listing is already there, please "claim"
your listing. Add an account and then claim it. I will allow you
to edit your own listing. DO NOT create a new listing if your
BBS already exists. That makes more work for me!

Thanks, and continue to enjoy the ride!

- Dave

The Telnet BBS Guide
http://www.telnetbbsguide.com

The BBS Corner
http://www.bbscorner.com

Diamond Mine Online BBS
http://www.dmine.com (info) & http://www.dmine.net (BBS access)
telnet://bbs.dmine.net
